# ard_complex() messaging

    Code
      ard_complex(ADSL, by = "ARM", variables = c("AGE", "BMIBL"), statistic = list(
        AGE = list(mean = function(x, ...) mean(x))))
    Condition
      Error in `ard_complex()`:
      ! The following columns do not have `statistic` defined: "BMIBL".

