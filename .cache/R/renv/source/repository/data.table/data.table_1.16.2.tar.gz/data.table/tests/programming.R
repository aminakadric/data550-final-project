require(data.table)
test.data.table(script="programming.Rraw")
