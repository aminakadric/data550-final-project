expect_1_row <- function(object) {
  expect_equal(
    nrow(object),
    1
  )
}
